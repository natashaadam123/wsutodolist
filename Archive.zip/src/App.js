import React from "react";
import TodoList from "./screens/todoList";

import "bootstrap/dist/css/bootstrap.min.css";
import "./App.scss";

function App() {
  return <TodoList />;
}

export default App;
