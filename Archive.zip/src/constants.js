export const checkBoxStatus = {
  completed: 1,
  pending: 0,
  crossed: -1,
};
